import { createJudgment } from "/adapters/judgment.mjs";
import { createCompletion } from "/adapters/completion.mjs";
import { createTranscription } from "/adapters/transcription.mjs";
import {
  executeArtifactPackage as renderSemanticMap,
  visibleFrameOf,
} from "/ui/semantic-map/runtime.js";
import * as protocol from "/ui/semantic-map/protocol/index.js";
// The provider's own limit on operations in one Decision, which its protocol
// entry does not carry; the architecture view is planned within it.
import { MAX_DECISION_OPERATIONS } from "/ui/semantic-map/domain/operation.js";
import { ACTION_ADD_EDGE, ACTION_ARCHITECTURE, judgeFramesFor, judgeSlotsFor, locateSlotsFor, readAnswers } from "/app/src/contract.mjs";
import { readBundle } from "/app/src/bundle.mjs";
import { runGoal } from "/app/src/goal.mjs";
import { runInventoryGoal } from "/app/src/completion.mjs";
import { FORMAT_ARCHITECTURE, readConfig } from "/app/src/config.mjs";
import {
  judgeRequestsOf,
  judgedOf,
  locateRequestsOf,
  locatedOf,
  planArchitecture,
  readManifest,
  routeOf,
  withArchitecture,
} from "/app/src/architecture.mjs";
import { EVIDENCE_CURRENT, commitDocument, currentClaims, restoreDocument } from "/app/src/document.mjs";
import {
  COMMIT_COMMITTED,
  COMMIT_UNVERIFIED,
  RESTORE_NO_LOG,
  RESTORE_RESTORED,
  commitLog,
  projectHistory,
  restoreLog,
  statesOf,
} from "/app/src/log.mjs";
import {
  appendRevert,
  apply,
  clearConversation,
  clearPending,
  createSession,
  discard,
  draftForJudgment,
  draftFull,
  draftUsed,
  noteRefused,
  propose,
  proposeArchitecture,
  recentConversation,
  spendPending,
  startNew,
  undo,
} from "/app/src/session.mjs";
import {
  OUTCOME_NO_CHANGE,
  OUTCOME_STEP,
  focusFor,
  pendingForJudgment,
  pendingHolds,
  placeableIds,
  requestFor,
  revertStep,
  revertable,
} from "/app/src/turn.mjs";
import {
  drawGraph,
  frameFor,
  reasonText,
  renderContext,
  renderControls,
  renderDiagnostic,
  renderArchitecture,
  renderDraft,
  renderBundleNotice,
  renderHistory,
  renderOutOfView,
  renderWorkingNotice,
} from "/app/src/render.mjs";

// The browser side of the app and nothing else: the elements, the platform
// adapters (storage, the origin-wide lock, fetch, the recognizer, the service
// worker) and the events that move one session reference from state to state.

const text = document.querySelector("#text");
const send = document.querySelector("#send");
const goalButton = document.querySelector("#goal");
const goalCancel = document.querySelector("#goal-cancel");
const mic = document.querySelector("#mic");
const newButton = document.querySelector("#new");
const status = document.querySelector("#status");
const historyPanel = document.querySelector("#history");
const confirmedSurface = document.querySelector("#confirmed-surface");
const draftList = document.querySelector("#draft");
const draftCount = document.querySelector("#draft-count");
const undoButton = document.querySelector("#undo");
const discardButton = document.querySelector("#discard");
const applyButton = document.querySelector("#apply");
const workingSurface = document.querySelector("#working-surface");
const outOfView = document.querySelector("#out-of-view");
const bundleNotice = document.querySelector("#bundle-notice");
const contextList = document.querySelector("#context-recent");
const contextSkipped = document.querySelector("#context-skipped");
const contextClear = document.querySelector("#context-clear");
const architectureSection = document.querySelector("#architecture");
const workingNotice = document.querySelector("#working-notice");
const cameraPart = document.querySelector("#camera-part");
// Local presentation only; never saved, sent to judgment, or used as focus.
let camera = null;

const controls = {
  send,
  mic,
  newMap: newButton,
  undo: undoButton,
  discard: discardButton,
  apply: applyButton,
  history: historyPanel,
  contextClear,
};

const { verifyDecisionLog } = protocol;

// The configuration this page was given (the config.v1.json beside it), set
// once it has been read and found valid; nothing below runs against storage or
// data before that.
let config;
// The architecture page only: the prepared source's public manifest as read
// (available, unavailable or invalid), and the saved document's cited snapshot
// and provenance, or null while nothing is saved.
let manifest = null;
let savedDocument = null;
const architecturePage = () => config?.persistence.format === FORMAT_ARCHITECTURE;
// Jev is asked about the source only while the manifest is available and is
// the very snapshot the saved document cites; otherwise nothing grounded in
// the source may be added.
const architectureReady = () => architecturePage() && manifest?.status === "available"
  && (savedDocument === null || savedDocument.evidence === EVIDENCE_CURRENT);

// The only place in the app that touches browser storage and its lock. The
// modules are pure and take these as arguments. localStorage is the one
// mechanism the config may name, and the key it declares also names the lock.
// The format it declares decides what is stored: the plain DecisionLog, or the
// architecture document that carries the same log with its provenance.
const read = key => localStorage.getItem(key);
const write = (key, value) => localStorage.setItem(key, value);
const lock = (name, run) => navigator.locks.request(name, run);
const commit = ({ graph, expected, draft }) => (architecturePage()
  ? commitDocument({
    graph, draft, saved: savedDocument, expected, key: config.persistence.key, read, write, lock, verifyDecisionLog, manifest,
  })
  : commitLog({ graph, expected, key: config.persistence.key, read, write, lock, verifyDecisionLog }));

// Capture and the surface are separate resources, so they are owned
// separately. `capturing` makes microphone capture exclusive to one voice
// attempt; `rendering` makes the decide-and-render critical section
// exclusive across every input and control. Typed submission is therefore
// allowed while voice is only listening, and refused only while the surface
// is being decided or rendered. Each path releases `rendering` solely when
// it is the owner, so neither can free the other's hold.
let capturing = false;
let rendering = false;
let typedHoldsRender = false;
let voiceHoldsRender = false;
let controlHoldsRender = false;
let goalActive = false;
let goalCancelled = false;

// Fail-closed latch. A stored log that is corrupt or foreign, and a change
// that was saved but could not be drawn, both leave the screen unable to
// speak for storage. Neither is transient, so no in-app control clears it:
// a reload recovers a display failure, and only clearing this origin's
// storage from outside the app recovers a log that is not usable here.
let blocked = false;
let storageEvidence = "unread";
let displayFailed = false;
let ready = false;
let resizePending = false;

// The one session reference, the saved graph's history as the left pane
// shows it, and the DataBundle this page loaded once.
let session;
let savedHistory = null;
let bundle;

const adopt = next => {
  session = next;
  if (next.pending === null) delete document.body.dataset.pending;
  else document.body.dataset.pending = next.pending.intent.missing;
};

const sync = () => {
  renderControls(controls, {
  idle: !rendering && !blocked,
  capturing,
  noLog: session.accepted === null,
  working: session.working !== null,
  draftLength: session.draft.length,
  conversationLength: session.conversation.length,
  });
  cameraPart.disabled = rendering || blocked || session.working === null;
  goalButton.disabled = rendering || blocked || session.working === null || draftFull(session);
  goalCancel.hidden = !goalActive;
  text.disabled = goalActive;
  renderWorkingNotice(workingNotice, { working: session.working !== null, draftLength: session.draft.length, storage: storageEvidence, displayFailed });
  if (ready && resizePending && !rendering && !blocked) {
    resizePending = false;
    queueMicrotask(() => withSurface("resize", resizeView));
  }
};

const setState = (state, message) => {
  document.body.dataset.state = state;
  status.textContent = message;
};

// The one record a camera id names in a graph, or null when it names none.
// Two records under one id, or a record that is neither a part nor an arrow,
// is a broken camera: it fails the drawing, never quietly the overview.
const cameraRecord = (graph, id) => {
  const matches = (graph?.records ?? []).filter(record => record.id === id);
  if (matches.length === 0) return null;
  if (matches.length > 1 || !["region", "relation"].includes(matches[0].type)) throw new Error("the camera names no single part or arrow");
  return matches[0];
};
// What a camera frames: null the overview, a part alone, an arrow by its two
// ends; undefined when its record is gone.
const cameraTarget = (graph, id) => {
  if (id === null) return null;
  const record = cameraRecord(graph, id);
  if (record === null) return undefined;
  return record.type === "region" ? record.id : [record.from, record.to];
};
// The arrow the latest unapplied single-arrow step drew (one add-edge Decision
// holding exactly one ConnectRegions), while Working holds it as one relation.
// A view choice only, never stored, sent or judged.
const latestDraftRelation = () => {
  const records = session.working?.records ?? [];
  const item = [...session.draft].reverse().find(entry => entry.step.action === ACTION_ADD_EDGE
    && entry.step.decision?.operations?.length === 1 && entry.step.decision.operations[0].type === "ConnectRegions");
  if (item === undefined) return null;
  const matches = records.filter(record => record.id === item.step.decision.operations[0].relationId);
  return matches.length === 1 && matches[0].type === "relation" ? matches[0] : null;
};

const showLists = () => {
  renderDraft(draftList, draftCount, { draft: session.draft, used: draftUsed(session), bundle });
  renderContext(contextList, contextSkipped, recentConversation(session, { architecture: architectureReady() }));
  const parts = session.working?.records.filter(record => record.type === "region" && record.parent !== null) ?? [];
  cameraPart.replaceChildren();
  const whole = document.createElement("option");
  whole.value = ""; whole.textContent = "全体の概要";
  cameraPart.append(whole);
  const layout = workingLayout();
  for (const part of parts.filter(part => layout?.bounds[part.id] !== undefined)) {
    const option = document.createElement("option");
    option.value = part.id; option.textContent = part.label;
    cameraPart.append(option);
  }
  // At most one arrow view: the arrow the camera now shows while it still
  // stands, else the latest unapplied single arrow, framed by its two ends.
  const named = camera === null ? [] : (session.working?.records ?? []).filter(record => record.id === camera);
  const arrow = named.length === 1 && named[0].type === "relation" ? named[0] : latestDraftRelation();
  const ends = arrow === null ? [] : [arrow.from, arrow.to].map(id => parts.find(part => part.id === id));
  if (arrow !== null && ends.every(end => end !== undefined && layout?.bounds[end.id] !== undefined)) {
    const option = document.createElement("option");
    option.value = arrow.id; option.textContent = `矢印: ${ends[0].label} → ${ends[1].label}`;
    cameraPart.append(option);
  }
  cameraPart.value = camera ?? "";
};

// The architecture page's account of what 作業図 now holds: the cited
// snapshot and whether it can still be checked, every drawn record with the
// claims about it (saved ones and those of unapplied architecture steps), and
// what the preparation did not analyze. Nothing on the plain page.
const showArchitecture = () => {
  if (!architecturePage()) return;
  const records = session.working?.records ?? [];
  const labelOf = new Map(records.filter(record => record?.type === "region").map(record => [record.id, record.label]));
  const labels = new Map([...labelOf, ...records.filter(record => record?.type === "relation")
    .map(record => [record.id, `${labelOf.get(record.from) ?? record.from} -[${record.kind}]-> ${labelOf.get(record.to) ?? record.to}`])]);
  const provenance = [...(savedDocument?.provenance ?? []), ...session.draft.filter(item => item.claims !== undefined)];
  const cited = savedDocument?.source ?? (manifest?.status === "available" ? manifest.source : null);
  const status = manifest?.status !== "available"
    ? `構成図の出典を利用できません: ${manifest?.reason ?? "未読込"}。コードに基づく追加はできません`
    : savedDocument !== null && savedDocument.evidence !== EVIDENCE_CURRENT
      ? `保存済みの図は ${savedDocument.source.handle}@${savedDocument.source.commit} を出典とし、現在の出典 ${manifest.source.commit} とは異なります。コードに基づく追加はできません`
      : `出典: ${cited.handle}@${cited.commit}`;
  const coverage = manifest?.status !== "available" ? [] : [
    ...manifest.coverage.notAnalyzed,
    ...manifest.coverage.unsupported.map(entry => `未解析: ${entry.path} (${entry.reason})`),
    ...manifest.coverage.skipped.map(entry => `図に含めないimport: ${entry.path} "${entry.specifier}" (${entry.reason})`),
    ...manifest.files.filter(file => file.class === "excluded").map(file => `取り込み対象外: ${file.path} (${file.reason})`),
  ];
  renderArchitecture(architectureSection, { status, claims: currentClaims(provenance, records), labels, coverage });
};

const showHistory = (note = null) => renderHistory(historyPanel, {
  projection: savedHistory,
  revertable: savedHistory === null ? [] : savedHistory.entries.map(entry => revertable(entry, savedHistory)),
  failure: note,
});

// Where a voice press has got to: preparing the microphone and the
// recognizer, listening, or deciding what was heard. The body state stays
// `pending` for the whole press; this only says what the user may do now,
// so "話してください" appears once capture has actually started.
const setVoice = (phase, message) => {
  if (phase === null) {
    delete document.body.dataset.voice;
    return;
  }
  document.body.dataset.voice = phase;
  status.textContent = message;
};

// Where the working graph is drawn, answered by the provider's public layout
// contract. The app never computes a position itself; a part can only be put
// beside another because the view says where that other one is. A graph the
// view cannot lay out offers no placement; everything else still works.
const layoutOf = working => {
  if (working === null) return null;
  try {
    return protocol.layoutBoundsFor(working.records, { pattern: protocol.GRAPH_PATTERN });
  } catch {
    return null;
  }
};
const workingLayout = () => layoutOf(session.working);

// The overview fits the whole graph; a selected local camera and a resize can
// leave parts outside the pane. They are still in 作業図; the person is told
// which ones, never that they are visible. Only
// 作業図 is asked, which is sound while both panes show the same frame: both
// have the same box and are given the same View.frame, which the browser test
// asserts.
const showOutOfView = () => {
  if (session.working === null) {
    renderOutOfView(outOfView, { outside: [] });
    return;
  }
  const layout = workingLayout();
  const shown = visibleFrameOf(workingSurface);
  if (layout === null || shown === null || shown.head !== session.working.head) {
    renderOutOfView(outOfView, { outside: null });
    return;
  }
  const whole = placeableIds(layout, session.working.records, shown.frame);
  renderOutOfView(outOfView, { outside: placeableIds(layout, session.working.records).filter(id => !whole.includes(id)) });
};

const failure = (reason, detail = null) => Object.freeze({ kind: "failed", reason, detail });
const judge = createJudgment();
const completion = createCompletion();

// Both panes point their cameras at the frame the working graph needs in the
// working pane's box, so the frame read from 作業図 holds for 確定図 too.
// Without a graph there is nothing to frame. A chosen camera whose record is
// not in a drawn graph fails the drawing; it never quietly becomes the overview.
const paneFrame = (graph, id = camera) => {
  if (graph === null) return null;
  const part = cameraTarget(graph, id);
  if (part === undefined) throw new Error("the selected camera names nothing in this graph");
  return frameFor({
    graph,
    width: workingSurface.clientWidth,
    height: workingSurface.clientHeight,
    protocol,
    part,
  });
};
const sameFrame = (left, right) => JSON.stringify(left) === JSON.stringify(right);
const drawWorking = async (graph, frame) => {
  // A removed part or arrow clears only this local view selection, never graph data.
  // Keep the old camera until the candidate Working drawing has succeeded.
  const nextCamera = camera !== null && cameraTarget(graph, camera) !== undefined ? camera : null;
  const nextFrame = frame === undefined ? paneFrame(graph, nextCamera) : frame;
  if (graph !== null && camera !== null && nextFrame === null) {
    throw new Error("the selected camera part is not placed");
  }
  await drawGraph({ graph, frame: nextFrame, mount: workingSurface, protocol, renderProjection: renderSemanticMap, document });
  camera = nextCamera;
};

// 確定図 is drawn at the frame 作業図 has now, and again only when that frame
// changed, so an edit that leaves the working graph's extent alone does not
// redraw the saved graph.
let confirmedFrame;
const followWorkingFrame = async () => {
  await new Promise(resolve => requestAnimationFrame(resolve));
  const frame = paneFrame(session.working);
  if (!sameFrame(confirmedFrame, frame)) {
    await drawGraph({ graph: session.accepted, frame, mount: confirmedSurface, protocol, renderProjection: renderSemanticMap, document });
    await drawWorking(session.working, frame);
    confirmedFrame = frame;
  }
};
// After a change to 作業図, the adopted draft stands whatever happens here.
// Either pane can fail; invalidate the pair rather than accepting another
// mutation against an unverified shared view. Returns true on failure.
const followOrReport = async () => {
  try {
    await followWorkingFrame();
    return false;
  } catch (error) {
    invalidateView();
    return true;
  }
};

const transcription = createTranscription();
const transcribe = async () => {
  const value = await transcription({ onListening: () => setVoice("listening", "voice: 聞いています。話してください") });
  text.value = value;
  return value;
};

// The changes that are not graph edges and that the focus may point at: the
// latest applied entry's edges and parts.
const lastApplied = () => (savedHistory?.entries.at(-1)?.facts ?? [])
  .filter(fact => fact.kind === "relation" || fact.kind === "region");

// The judged request for one utterance against a session, shared by Send,
// Voice and a scoped Goal. When the caller passes architecture - read once,
// while the source can be cited - it is an architecture intent: the same request, with the snapshot's
// parts by path or identifier beside it, the conversation with its references,
// and no code.
const intentFor = (latest, utterance, { layout, offeredFrame, pending, lastApplied, architecture }) => {
  const steps = draftForJudgment(latest);
  const plain = requestFor({
    working: latest.working,
    utterance,
    bundle,
    layout,
    offeredFrame,
    draft: steps,
    focus: focusFor({ draft: steps, lastApplied }),
    pending,
    recent: recentConversation(latest).recent,
  });
  if (!architecture) return plain;
  const bound = withArchitecture(plain, manifest);
  return { turn: bound.turn, request: { ...bound.request, state: { ...bound.request.state,
    context: { recent: recentConversation(latest, { architecture: true }).recent },
  } } };
};

// Send and Voice take the same path, and neither touches 確定図 or storage:
// the utterance is judged against 作業図 and every unapplied step, and a
// usable answer becomes one more step on 作業図, drawn before it is adopted.
// Returns how the input ended; only an utterance the judgment binding judged joins the
// conversation, which the session records.
const decide = async (value, source) => {
  renderDiagnostic(status, null);
  if (typeof value !== "string" || value.trim().length === 0) {
    return Object.freeze({ kind: OUTCOME_NO_CHANGE, reason: "nothing-said" });
  }
  if (draftFull(session)) return Object.freeze({ kind: OUTCOME_NO_CHANGE, reason: "draft-full", state: "draft-full" });

  const working = session.working;
  const layout = workingLayout();
  const asked = visibleFrameOf(workingSurface);
  const offeredFrame = asked !== null && asked.head === working.head ? asked.frame : null;
  const placeable = layout === null ? [] : [...placeableIds(layout, working.records, offeredFrame)];

  // A held placement is spent by this utterance even if the provider later
  // times out or refuses it, and is passed on explicitly for the repair.
  const spent = spendPending(session);
  adopt(spent.session);
  const held = spent.held;
  const stillHeld = held !== null && pendingHolds(held.intent, { head: working.head, frame: offeredFrame, offered: placeable });

  const architecture = architectureReady();
  const { turn, request } = intentFor(session, value, { layout, offeredFrame,
    pending: stillHeld ? pendingForJudgment(held.intent) : null, lastApplied: lastApplied(), architecture });
  const answer = await judge(request);
  if (answer.kind === "failed") return answer;
  const answers = answer.decision.answers;

  // An architecture answer that names one part goes on to a judge of that
  // part's section alone. One that names neither the whole nor a part
  // confidently is first located from the code itself - one frame per part,
  // one after another, each shown that part's own text by the server; the
  // first that fails, or is not answered completely on its own question, ends
  // the utterance, and nothing after it is asked - and every part located is
  // then judged together, as one section. A section is judged in its frames -
  // one request, or several - one after another, each shown its own files by
  // the server, and ended by the first that fails or is not answered
  // completely on its own questions, just as a locate is.
  const composing = architecture && answers?.action?.choice === ACTION_ARCHITECTURE;
  const route = composing ? routeOf(turn, answers) : null;
  let focus = route?.route === "part" ? route.focus : null;
  let located = null;
  const frames = route?.route === "locate" ? locateRequestsOf(manifest, request) : null;
  if (frames !== null) {
    const answered = [];
    for (const frame of frames) {
      const locating = await judge(frame);
      if (locating.kind === "failed") return locating;
      if (readAnswers(locating.decision.answers, locateSlotsFor(frame.state.architecture.focus)) === null) return failure("judge-contract");
      answered.push(Object.freeze({ request: frame, answers: locating.decision.answers }));
    }
    located = Object.freeze(answered);
    const found = locatedOf(manifest, located);
    focus = found !== null && found.focus.length > 0 ? found.focus : null;
  }
  const judges = focus === null ? null : judgeRequestsOf(manifest, focus, value);
  let judged = null;
  if (judges !== null) {
    const plan = judgeFramesFor(judges[0].state.architecture);
    const answered = [];
    for (const [index, frame] of judges.entries()) {
      const judging = await judge(frame);
      if (judging.kind === "failed") return judging;
      if (readAnswers(judging.decision.answers, judgeSlotsFor(plan[index].section)) === null) return failure("judge-contract");
      answered.push(Object.freeze({ request: frame, answers: judging.decision.answers }));
    }
    judged = judgedOf(manifest, focus, Object.freeze(answered));
    if (judged === null) return failure("judge-contract");
  }

  // Read in the same synchronous run the answer is judged in.
  const visibleFrame = visibleFrameOf(workingSurface);
  const input = Object.freeze({ source, text: value });
  const before = session;
  const transition = composing
    ? await proposeArchitecture(session, {
      planned: await planArchitecture({ working, turn, answers, judged, located, manifest, protocol, operationsMax: MAX_DECISION_OPERATIONS }),
      input,
      protocol,
      reference: judged === null ? null : { source: manifest.source, focus: judged.section.focus },
    })
    : await propose(session, { turn, answers, protocol, bundle, layout, visibleFrame, input, repair: held });
  if (transition.result.outcome === OUTCOME_NO_CHANGE) {
    adopt(transition.session);
    renderDiagnostic(status, {
      answers: answer.decision.answers,
      placeable,
      undoRequest: transition.result.undoRequest === true,
      frame: visibleFrame,
      revision: working.head,
    });
    return Object.freeze({
      kind: OUTCOME_NO_CHANGE,
      reason: transition.result.reason,
      state: transition.result.undoRequest === true ? "undo-request" : "no-change",
    });
  }
  if (transition.result.outcome !== OUTCOME_STEP) {
    adopt(transition.session);
    return failure(transition.result.reason, transition.result.detail ?? null);
  }
  // A step joins 作業図 only once it is drawn. If it cannot be, the pane still
  // shows the map it had (drawGraph keeps it) and the utterance counts as refused.
  try {
    await drawWorking(transition.session.working);
  } catch (error) {
    adopt(noteRefused(before, input));
    return failure("display-failed", "operation_failed");
  }
  adopt(transition.session);
  return Object.freeze({ kind: OUTCOME_STEP });
};

// How an input ends. Only a drawn step changes 作業図; "no change" and a
// failure leave it exactly as it was. 確定図 and storage are never touched.
const finish = async (prefix, outcome) => {
  showLists();
  showArchitecture();
  if (outcome.kind === OUTCOME_STEP) {
    showOutOfView();
    const drafted = `${prefix}: 作業図に追加しました (未反映)`;
    if (!(await followOrReport())) {
      setState("drafted", drafted);
      showHistory();
    }
    return;
  }
  if (outcome.kind === OUTCOME_NO_CHANGE) {
    setState(outcome.state ?? "no-change", `${prefix}: no change - ${reasonText(outcome.reason)}`);
    showHistory();
    return;
  }
  // The status names the phase that failed; history keeps what was said about it.
  setState("failed", `${prefix}: failed - ${reasonText(outcome.reason)}`);
  showHistory(`failed: ${reasonText(outcome.reason, outcome.detail)}`);
};

send.addEventListener("click", async () => {
  if (blocked) return;
  if (rendering) {
    setState("pending", "type: busy");
    return;
  }
  rendering = true;
  typedHoldsRender = true;
  sync();

  setState("pending", "type: working");
  try {
    await finish("type", await decide(text.value, "typed"));
  } catch (error) {
    await finish("type", failure("error", "operation_failed"));
  } finally {
    if (typedHoldsRender) {
      rendering = false;
      typedHoldsRender = false;
    }
    sync();
  }
});

// One press is all it takes: nothing here needs the text field. The surface
// critical section begins once transcription has finished; its claim is taken
// before the first await after that, and the finally releases it.
const hear = async () => {
  const heard = await transcribe();
  if (typeof heard !== "string") return failure("voice-failed", "transcription_invalid_text");
  if (rendering) return failure("error", "surface is busy");
  rendering = true;
  voiceHoldsRender = true;
  sync();
  setVoice("deciding", "voice: 判定中");
  return decide(heard, "voice");
};

mic.addEventListener("click", async () => {
  if (blocked) return;
  if (capturing || rendering) {
    setState("pending", "voice: busy");
    return;
  }
  capturing = true;
  sync();

  setState("pending", "voice: preparing");
  setVoice("preparing", "voice: 準備中です。まだ話さないでください");
  try {
    await finish("voice", await hear());
  } catch (error) {
    await finish("voice", failure("voice-failed", "operation_failed"));
  } finally {
    if (voiceHoldsRender) {
      rendering = false;
      voiceHoldsRender = false;
    }
    capturing = false;
    setVoice(null);
    sync();
  }
});

// The working-graph controls share the surface with the inputs, so they take
// the same exclusive hold and release it only as its owner. Each drops a held
// placement and the last turn's diagnostic, whatever it then does.
const withSurface = async (label, run) => {
  if (!ready || blocked || rendering) return;
  adopt(clearPending(session));
  rendering = true;
  controlHoldsRender = true;
  renderDiagnostic(status, null);
  sync();
  setState("pending", `${label}: working`);
  try {
    await run();
  } catch (error) {
    setState("failed", `${label}: failed`);
    showHistory(`failed: ${"operation_failed"}`);
  } finally {
    if (controlHoldsRender) {
      rendering = false;
      controlHoldsRender = false;
    }
    sync();
  }
};

// Draw a new working graph and adopt it, then report as a control does.
const showWorking = async (next, state, message) => {
  await drawWorking(next.working);
  adopt(next);
  showLists();
  showArchitecture();
  showOutOfView();
  if (!(await followOrReport())) {
    setState(state, message);
    showHistory();
  }
};

const refusedBy = (label, result) => {
  if (result.outcome === OUTCOME_NO_CHANGE) {
    setState(result.reason === "draft-full" ? "draft-full" : "no-change", `${label}: no change - ${reasonText(result.reason)}`);
    showHistory();
    return;
  }
  setState("failed", `${label}: failed`);
  showHistory(`failed: ${reasonText(result.reason, result.detail ?? null)}`);
};

// Goal is a separate, finite multi-step meaning; ordinary Send is unchanged.
// One input owns the surface until mechanical STOP, never until an oracle
// says the goal succeeded. Cancel cannot undo an already adopted step.
goalCancel.addEventListener("click", () => { goalCancelled = true; });
goalButton.addEventListener("click", () => withSurface("goal", async () => {
  goalActive = true;
  goalCancelled = false;
  delete document.body.dataset.goal;
  sync();
  try {
    const utterance = text.value;
    // A scoped Goal asks this page's own intent before each change, built for
    // the latest session as Send builds it, with no frame or held placement,
    // and only while the source can be cited.
    const resolveIntent = architectureReady()
      ? latest => intentFor(latest, utterance, { layout: layoutOf(latest.working), offeredFrame: null, pending: null,
        lastApplied: lastApplied(), architecture: true })
      : undefined;
    const goal = resolveIntent === undefined ? runInventoryGoal : runGoal;
    const result = await goal({ utterance, bundle, protocol, resolveIntent, manifest: architectureReady() ? manifest : null,
      check: completion.check, complete: completion.complete,
      current: () => session, ask: judge, cancelled: () => goalCancelled || resizePending || blocked,
      adopt: async next => {
        await showWorking(next, "drafted", "goal: Working updated (unconfirmed)");
        if (blocked) throw new Error("goal display unverified");
      },
    });
    document.body.dataset.goal = JSON.stringify(result);
    if (result.reason === "adoption-unknown") invalidateView();
    else setState("goal-stopped", `goal: stopped - ${result.reason} (unconfirmed)`);
  } finally {
    goalActive = false;
    sync();
  }
}));

// 新しい図: only where there is no log. The typed name becomes a new, empty
// map on 作業図; nothing is stored until 確定図に反映.
newButton.addEventListener("click", () => withSurface("new", async () => {
  const { session: next, result } = await startNew(session, { title: text.value, protocol });
  if (result.outcome !== OUTCOME_STEP) {
    refusedBy("new", result);
    return;
  }
  await showWorking(next, "drafted", "new: 作業図に新しい図を作りました (未反映)");
}));

// 元に戻す drops the last unapplied step and nothing else, never below what is
// saved, and there is no redo.
undoButton.addEventListener("click", () => withSurface("undo", async () => {
  if (session.draft.length === 0) return;
  await showWorking(await undo(session, { verifyDecisionLog }), "undone", "作業図の最後の変更を元に戻しました");
}));

// 作業図を破棄 returns the working graph to the saved one.
discardButton.addEventListener("click", () => withSurface("discard", async () => {
  if (session.draft.length === 0) return;
  await showWorking(discard(session), "discarded", "作業図を破棄しました");
}));

// 会話をクリア forgets the recent conversation; the next request sends none.
// It changes neither pane.
contextClear.addEventListener("click", () => {
  if (blocked || rendering) return;
  adopt(clearConversation(session));
  renderDiagnostic(status, null);
  showLists();
  sync();
});

// A partial pair render cannot truthfully advertise a shared frame. Keep the
// requested camera visible, block mutations, and recover by reading on reload.
const invalidateView = () => {
  confirmedFrame = undefined;
  displayFailed = true;
  blocked = true;
  setState("view-unverified", "両方の表示枠を確認できません。再読み込みしてください");
  showHistory("display failed: operation_failed");
};
const resizeView = async () => {
  try {
    confirmedFrame = undefined;
    await followWorkingFrame();
    showOutOfView();
    setState("resized", "両方の図を現在の表示枠に合わせました");
  } catch { invalidateView(); }
};
cameraPart.addEventListener("change", () => withSurface("camera", async () => {
  camera = cameraPart.value || null;
  try {
    await drawWorking(session.working);
    await followWorkingFrame();
    showOutOfView();
    setState("camera", camera === null ? "全体の概要を表示しています"
      : Array.isArray(cameraTarget(session.working, camera))
        ? "選んだ矢印の両端が収まるように表示しています。表示外の部品も図には残っています。長いラベルは収まらない場合があります"
        : "選んだ部品を等倍で表示しています。表示外の部品も図には残っています。長いラベルは収まらない場合があります");
  } catch { invalidateView(); }
}));
window.addEventListener("resize", () => {
  resizePending = true;
  if (ready) sync();
});

// 確定図に反映: the only write to storage and the only change to 確定図. Every
// unapplied Decision is written at once, under the origin-wide lock, only as
// a verified strict extension of what storage still holds, and read back. A
// refused Apply keeps 作業図 exactly as it was. Once the write has landed,
// a failure to draw it blocks the page until a reload.
applyButton.addEventListener("click", () => withSurface("apply", async () => {
  if (session.draft.length === 0) return;
  const { session: next, result } = await apply(session, { commit });
  // Storage that cannot be vouched for after a write leaves the screen unable
  // to speak for it: the page blocks until a reload reads what is really there.
  if (result.status === COMMIT_UNVERIFIED) {
    storageEvidence = "unverified";
    blocked = true;
    setState("storage-unverified", "apply: storage could not be verified - reload to recover");
    showHistory(`failed: ${reasonText(result.status, result.reason)}`);
    return;
  }
  if (result.status !== COMMIT_COMMITTED) {
    storageEvidence = "unread";
    setState("failed", "apply: failed");
    showHistory(`failed: ${reasonText(result.status, result.reason ?? null)}`);
    return;
  }
  adopt(next);
  storageEvidence = "verified";
  showLists();
  try {
    savedHistory = await projectHistory(next.accepted, { verifyDecisionLog });
    // The provenance now saved, read back as stored rather than assumed.
    if (architecturePage()) {
      const saved = await restoreDocument({ key: config.persistence.key, read, verifyDecisionLog, manifest });
      if (saved.status !== RESTORE_RESTORED || saved.stored !== next.stored) throw new Error(`the saved document reads back as ${saved.status}`);
      savedDocument = saved;
    }
    showArchitecture();
    showHistory();
    sync();
    confirmedFrame = undefined;
    await followWorkingFrame();
    showOutOfView();
  } catch (error) {
    blocked = true;
    displayFailed = true;
    setState("saved-display-failed", "apply: saved, display failed - reload to recover");
    showHistory(`display failed: ${"operation_failed"}`);
    return;
  }
  setState("applied", "確定図に反映しました");
  showHistory();
}));

// 取り消しを作業図に追加: the opposite of an applied entry, read off the
// provider's states on either side of it, checked against 作業図 as it is now,
// and added there as one more step. 確定図 is untouched until Apply.
historyPanel.addEventListener("click", event => {
  const button = event.target.closest("button[data-revert]");
  if (!button || button.disabled) return;
  const index = Number(button.dataset.revert);
  withSurface("revert", async () => {
    const states = await statesOf(session.accepted.log, verifyDecisionLog);
    const built = await revertStep({ before: states[index], after: states[index + 1], working: session.working, protocol });
    if (built.outcome !== OUTCOME_STEP) {
      refusedBy("revert", built);
      return;
    }
    const { session: next, result } = await appendRevert(session, { step: built.step, protocol });
    if (result.outcome !== OUTCOME_STEP) {
      refusedBy("revert", result);
      return;
    }
    await showWorking(next, "drafted", "取り消しを作業図に追加しました (未反映)");
  });
});

// A JSON document of this origin, or why there is none: the network, the
// status, or a body that is not JSON.
const fetchJson = async path => {
  let response;
  try {
    response = await fetch(path, { cache: "no-store" });
  } catch (error) {
    return Object.freeze({ reason: `network: ${"operation_failed"}` });
  }
  if (!response.ok) return Object.freeze({ reason: `HTTP ${response.status}` });
  try {
    return Object.freeze({ value: await response.json() });
  } catch (error) {
    return Object.freeze({ reason: `invalid JSON: ${"operation_failed"}` });
  }
};

// The configuration is the first thing read, from its one fixed name beside
// the page: /data/config.v1.json for the plain page, and the architecture
// page's own under /architecture/.
const CONFIG_PATH = new URL("data/config.v1.json", document.baseURI).pathname;
const loadConfig = async () => {
  const fetched = await fetchJson(CONFIG_PATH);
  return fetched.reason === undefined ? readConfig(fetched.value) : Object.freeze({ error: fetched.reason });
};

// The DataBundle from where the config says. One that cannot be fetched or
// read disables only the capabilities it would have provided, and the notice
// names them and says why; nothing is offered in their place.
const BUNDLE_CAPABILITIES = Object.freeze({ parts: "部品の追加", diagrams: "図の作成" });
const loadBundle = async path => {
  const fetched = await fetchJson(path);
  const offered = readBundle(fetched.reason === undefined ? fetched.value : null);
  const affected = Object.keys(BUNDLE_CAPABILITIES).filter(name => offered[name] === null).map(name => BUNDLE_CAPABILITIES[name]);
  const reason = fetched.reason ?? (offered.version === null ? "invalid bundle" : "invalid section");
  return { offered, affected, reason };
};

let bootState;
let bootMessage;
let bootFailure = null;
const configured = await loadConfig();
if (configured.error !== undefined) {
  // Without a valid config nothing is read, fetched, asked or drawn, and the
  // page is blocked until a reload finds one.
  blocked = true;
  bundle = readBundle(null);
  adopt(createSession({ accepted: null, stored: null }));
  showLists();
  [bootState, bootMessage] = ["failed", "the configuration is unusable - nothing was read or drawn"];
  bootFailure = `config rejected: ${configured.error}`;
} else {
  config = configured;
  const loaded = await loadBundle(config.data.bundle);
  bundle = loaded.offered;
  renderBundleNotice(bundleNotice, loaded);

  // Storage decides what this origin starts from. No log is NO_LOG: nothing is
  // drawn until the person makes a map. A corrupt or foreign log is left exactly
  // where it is, blocks the page and draws nothing; the only way forward is an
  // explicit clear from outside the app. 作業図 starts as the saved graph:
  // nothing unapplied survives a reload, and the conversation starts empty.
  //
  // The architecture page reads its prepared source's public manifest first; a
  // saved document is checked against it only when it cites the same snapshot.
  if (architecturePage()) {
    const fetched = await fetchJson(config.data.source);
    manifest = fetched.reason === undefined ? readManifest(fetched.value) : Object.freeze({ status: "unavailable", reason: fetched.reason });
  }
  const restored = architecturePage()
    ? await restoreDocument({ key: config.persistence.key, read, verifyDecisionLog, manifest })
    : await restoreLog({ key: config.persistence.key, read, verifyDecisionLog });
  if (restored.status === RESTORE_RESTORED) {
    storageEvidence = "verified";
    savedHistory = restored.projection;
    if (architecturePage()) savedDocument = restored;
    adopt(createSession({ accepted: restored.graph, stored: architecturePage() ? restored.stored : restored.graph.log }));
  } else {
    storageEvidence = restored.status === RESTORE_NO_LOG ? "absent" : "invalid";
    blocked = restored.status !== RESTORE_NO_LOG;
    adopt(createSession({ accepted: null, stored: null }));
  }
  // With no source to cite and nothing saved, the architecture page has
  // nothing it could truthfully draw or save: it says why and stays blocked.
  const sourceMissing = architecturePage() && manifest.status !== "available" && restored.status === RESTORE_NO_LOG;
  if (sourceMissing) blocked = true;
  showLists();
  showArchitecture();
  showHistory(bootFailure);
  sync();

  try {
    await followWorkingFrame();
    showOutOfView();
    if (sourceMissing) {
      [bootState, bootMessage] = ["failed", "the prepared source is unavailable - nothing can be drawn from it"];
      bootFailure = `${reasonText("architecture-unavailable")}: ${manifest.reason}`;
    } else if (blocked) {
      [bootState, bootMessage] = ["failed", "saved history is unusable - clear this site's storage to start over"];
      bootFailure = `stored log rejected: ${restored.reason}`;
    } else if (restored.status === RESTORE_RESTORED) {
      [bootState, bootMessage] = ["restored", `restored: ${savedHistory.entries.length} confirmed`];
    } else {
      [bootState, bootMessage] = ["no-log", "no saved graph - type a name and press 新しい図"];
    }
  } catch (error) {
    // The stored graph is intact but undrawable. Nothing was lost, so this is
    // the same saved-but-not-displayed state a failed render produces.
    blocked = true;
    displayFailed = true;
    [bootState, bootMessage] = ["saved-display-failed", "stored graph could not be drawn - reload to retry"];
    bootFailure = `display failed: ${"operation_failed"}`;
  }
}
// The body state is set last, with every control already in its place: it is
// what tells anyone watching that the page is ready.
showHistory(bootFailure);
ready = true;
sync();
setState(bootState, bootMessage);
